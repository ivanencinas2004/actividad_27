<?php
include("header.html");
?>
<h2>Registor de usuario</h2>

<?php
include("footer.html.");
?>
