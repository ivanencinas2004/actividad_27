<?php
include("header.html");
?>
<h2>Log out</h2>

<?php
include("footer.html.");
?>
